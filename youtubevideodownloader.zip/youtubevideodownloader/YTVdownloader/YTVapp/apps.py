from django.apps import AppConfig


class YtvappConfig(AppConfig):
    name = 'YTVapp'
